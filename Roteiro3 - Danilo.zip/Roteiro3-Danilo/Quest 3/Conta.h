#pragma once
#include <iostream> 

class Conta 
{
protected:
    std::string nomeCliente;
    int numeroConta;
    double saldo;
public:
    Conta();
    Conta(std::string str, int nc, double sl);
    std::string getNomeCliente();
    int getNumeroConta();
    double getSaldo();//n precisa de set saldo :)
    bool sacar(double valor);
    void depositar(double valor);
};