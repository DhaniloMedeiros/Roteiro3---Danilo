#include "Conta.h"
class Poupanca : public Conta
{
private:
    int variacao;
    double taxaRendimento;
public:
    Poupanca();
    Poupanca(std::string str, int nc, double sl, int v, double tr);
    int getVariacao();
    int getTaxaRendimento();
    double render();
};