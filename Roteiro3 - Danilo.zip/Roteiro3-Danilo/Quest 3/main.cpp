#include "Poupanca.h"
#include "ContaEspecial.h"
#include "ContaCorrente.h"
#include "Conta.h"

void printDados(Conta * acc){
    std::cout << "\nNUMERO DA CONTA: " << acc->getNumeroConta() << std::endl; 
    std::cout << "O usuario " << acc->getNomeCliente() << "\nPossui R$: " << acc->getSaldo();
    std::cout << " disponivel(is)" << std::endl;
}
void printPoupanca(Poupanca * acc){
    std::cout << "\nNUMERO DA CONTA: " << acc->getNumeroConta() << std::endl; 
    std::cout << "O usuario " << acc->getNomeCliente() << "\nPossui R$: " << acc->getSaldo();
    std::cout << " disponivel(is)" << std::endl;
    std::cout << "Variacao: " << acc->getVariacao() << std::endl;
    std::cout << "Taxa de rendimento de " << acc->getTaxaRendimento() << "% ao mes."<<std::endl; 
}
void limpaTela(void){
    #ifdef __unix__
        system("clear");
    #elif WIN32
        system("cls");
    #endif
}

int main(){//sacar depositar :)
    double cambio;
    ContaCorrente *cc1 = new ContaCorrente("Chico Bento", 24001, 1000, 2500);
    ContaEspecial *ce1 = new ContaEspecial("Donald Trump", 10030, 2000, 5000);
    Poupanca *pp1 = new Poupanca("Hermanoteu", 24003, 8000, 51, 10);
    //o metodo definir limite ta dentro do construtor da classe
    limpaTela();
    std::cout << "\nConta Corrente1:\n";
    printDados(cc1);
    std::cout << "\nConta Especial1:\n";
    printDados(ce1);
    std::cout << "\nPoupanca1:\n";
    printPoupanca(pp1);
    
    std::cout << "\nDigite o valor que deseja sacar da Conta Corrente 1, caso o valor extrapole\no saldo disponivel o cambio é invalidado:";
    std::cin >> cambio;
    if(cc1->sacar(cambio))
        std::cout << "\ncambio efetuado com sucesso.";
    else
        std::cout << "\nLimite estourou.";
    printDados(cc1);
    std::cout << "\nDigite o valor que deseja depositar na conta:";
    std::cin >> cambio;
    cc1->depositar(cambio);
    printDados(cc1);
    std::cout << "\nAperte ENTER, pra realizar as mesmas operacoes na conta especial.";
    getchar();
    getchar();
    limpaTela();

    ///////////
    
    printDados(ce1);
    std::cout << "\nDigite o valor que deseja sacar da Conta Especial 1 caso o valor extrapole\no saldo disponivel o cambio é invalidado:";
    std::cin >> cambio;
    if(ce1->sacar(cambio))
        std::cout << "\ncambio efetuado com sucesso.";
    else
        std::cout << "\nLimite estourou.";

    printDados(ce1);
    std::cout << "\nDigite o valor que deseja depositar na conta:";
    std::cin >> cambio;
    ce1->depositar(cambio);
    printDados(ce1);
    std::cout << "\nAperte ENTER, pra render a Poupanca 1.";
    getchar();
    getchar();
    limpaTela();

    ///////////
    bool loop = true;
    while (loop){
        limpaTela();
        printPoupanca(pp1);
        int opcao;
        std::cout << "\nDigite 1 para render a poupanca ou 2 pra finalizar o programa:";
        std::cin >> opcao;
        switch (opcao){
            case 1:
                pp1->render();
                std::cout << "Poupanca pos-rendimento:\n";
                printPoupanca(pp1);
                std::cout << "\nAperte ENTER.";
                getchar();
                getchar();
                break;
            case 2:
                loop = false;
                break;
            default:
                break;
        }
    }
    
    return 0;
}