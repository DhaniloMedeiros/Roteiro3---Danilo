#pragma once
#include "ContaCorrente.h"

class ContaEspecial : public ContaCorrente
{   
    public: 
        ContaEspecial();
        ContaEspecial(std::string str, int nc, double sl, double sal);
        double definirLimite();//3x salario mensal
};