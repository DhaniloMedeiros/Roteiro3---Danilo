#include "Conta.h"

Conta::Conta(){
    nomeCliente = "NULL";
    numeroConta = saldo = 0;
}
Conta::Conta(std::string str, int nc, double sl){
    nomeCliente = str;
    numeroConta = nc;
    saldo = sl;
}
std::string Conta::getNomeCliente(){
    return nomeCliente;
}
int Conta::getNumeroConta(){
    return numeroConta;
}
double Conta::getSaldo(){
    return saldo;
}
bool Conta::sacar(double valor){
    saldo -= valor;
    if(saldo < 0){//saque invalido
        saldo += valor;
        return false;
    }
    else
        return true;
}
void Conta::depositar(double valor){
    saldo += valor;
}