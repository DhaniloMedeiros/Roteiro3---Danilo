#include "ContaEspecial.h"

double ContaEspecial::definirLimite(){//3x salario mensal
    limite = 3*salario;
    return limite;
}
ContaEspecial::ContaEspecial(std::string str, int nc, double sl, double sal){
    nomeCliente = str;
    numeroConta = nc;
    saldo = sl;
    salario = sal;
    definirLimite();
}
ContaEspecial::ContaEspecial(){
    nomeCliente = "NULL";
    salario = numeroConta = saldo = limite = 0;
}