#include "ContaCorrente.h"

ContaCorrente::ContaCorrente(){
    salario = 0;
    limite = 0;
}
ContaCorrente::ContaCorrente(std::string str, int nc, double sl, double sal){
    nomeCliente = str;
    numeroConta = nc;
    saldo = sl;
    salario = sal;
    definirLimite();
}
double ContaCorrente::definirLimite(){
    limite = salario*2;
    return limite;
}