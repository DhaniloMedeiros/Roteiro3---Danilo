#pragma once
#include "Conta.h"
class ContaCorrente : public Conta
{
protected:
    double salario;
    double limite;  
public:
    ContaCorrente();
    ContaCorrente(std::string str, int nc, double sl, double sal);
    double definirLimite();
};
