#include "Poupanca.h"

Poupanca::Poupanca(){
    variacao = 1;
    taxaRendimento = 0;
}
Poupanca::Poupanca(std::string str, int nc, double sl, int v, double tr){
    nomeCliente = str;
    numeroConta = nc;
    saldo = sl;
    variacao = v;//1 ou 51
    taxaRendimento = tr;
}
int Poupanca::getVariacao(){
    return variacao;
}
int Poupanca::getTaxaRendimento(){
    return taxaRendimento;
}
double Poupanca::render(){
    if(variacao == 1){
        saldo *= 1 + (taxaRendimento/100);
    }else if(variacao == 51){
        saldo *= 1 + (taxaRendimento + 0.5)/100;
    }
}