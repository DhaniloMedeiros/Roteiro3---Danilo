#include "Conta.h"
#include "ContaEspecial.h"

void printDados(Conta * acc){
    std::cout << "\nNUMERO DA CONTA: " << acc->getnumeroConta() << std::endl; 
    std::cout << "O usuario " << acc->getnomeCliente() << "\nPossui R$: " << acc->getsaldo();
    std::cout << " disponivel(is)" << std::endl;
}
void limpaTela(void){
    #ifdef __unix__
        system("clear");
    #elif WIN32
        system("cls");
    #endif
}

int main(){//sacar depositar :)
    double saque;
    Conta *pobre = new Conta("Chico Bento", 2000, 34, 500);
    ContaEspecial *rico = new ContaEspecial("Donald Trump", 10000, 1, 5000);
    //o metodo definir limite ta dentro do construtor da classe
    limpaTela();
    printDados(pobre);
    printDados(rico);
    
    std::cout << "\nDigite o valor que deseja sacar da conta pobre, caso o valor extrapole\no limite de " << 
                pobre->getlimite() << "R$ o saque é invalidado:";
    std::cin >> saque;
    if(pobre->sacar(saque))
        std::cout << "\nSaque efetuado com sucesso.";
    else
        std::cout << "\nLimite estourou.";

    printDados(pobre);
    std::cout << "\nDigite o valor que deseja depositar na conta pobre:";
    std::cin >> saque;
    pobre->depositar(saque);
    printDados(pobre);
    std::cout << "\nAperte ENTER, pra realizar as mesmas operacoes no cliente rico.";
    getchar();
    getchar();
    limpaTela();
    ///////////
    std::cout << "\nDigite o valor que deseja sacar da conta rica caso o valor extrapole\no limite de " << 
                rico->getlimite() << "R$ o saque é invalidado:";
    std::cin >> saque;
    if(rico->sacar(saque))
        std::cout << "\nSaque efetuado com sucesso.";
    else
        std::cout << "\nLimite estourou.";

    printDados(rico);
    std::cout << "\nDigite o valor que deseja depositar na conta rico:";
    std::cin >> saque;
    rico->depositar(saque);
    printDados(rico);
    return 0;
}
