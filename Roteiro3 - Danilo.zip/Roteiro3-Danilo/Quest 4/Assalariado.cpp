#include "Assalariado.h"

Assalariado::Assalariado(){
    salario = 0;
}
Assalariado::Assalariado(double sal, std::string str, int mat){
    salario = sal;
    nome = str;
    matricula = mat;
}
double Assalariado::calculaSalario(){
    return salario;
}