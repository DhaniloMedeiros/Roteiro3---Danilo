#pragma once
#include "Funcionario.h"

class Assalariado : public Funcionario
{
private:
    double salario;
public:
    Assalariado();
    Assalariado(double sal, std::string str, int mat);
    double calculaSalario();
};