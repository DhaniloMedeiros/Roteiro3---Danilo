#include "SistemaGerenciaFolha.h"

SistemaGerenciaFolha::SistemaGerenciaFolha(double om){
    orcamentoMaximo = om;
}
void SistemaGerenciaFolha::setFuncionarios(Funcionario *func){
    funcionarios.push_back(func);
}
std::vector<Funcionario*> SistemaGerenciaFolha::getFuncionarios(){
    return funcionarios;
}
double SistemaGerenciaFolha::calculaValorTotalFolha(){
    double folhaDePagamento = 0;
    for(int i = 0; i < funcionarios.size(); i++){
        folhaDePagamento += funcionarios[i]->calculaSalario();
    }
    if(folhaDePagamento <= orcamentoMaximo)
        return folhaDePagamento;
    else
        throw OrcamentoEstouradoException(505);
}
double SistemaGerenciaFolha::consultaSalarioFuncionario(std::string str){
    for(int i = 0; i < funcionarios.size(); i++){
        std::string consulta = funcionarios[i]->getNome();
        size_t found = consulta.find(str);
        if(found != std::string::npos)
            return funcionarios[i]->calculaSalario();
    }
    throw FuncionarioNaoExisteException(404);
}