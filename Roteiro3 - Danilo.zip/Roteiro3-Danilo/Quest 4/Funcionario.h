#pragma once
#include <iostream>
class Funcionario
{
protected:
    std::string nome;
    int matricula;
public:
    Funcionario();
    Funcionario(std::string str, int mat);
    std::string getNome();
    int getMatricula();
    virtual double calculaSalario() = 0;
};