#include "SistemaGerenciaFolha.h"
#include "Assalariado.h"
#include "Horista.h"
#include "Comissionado.h"

void limpaTela(void){
    #ifdef __unix__
        system("clear");
    #elif WIN32
        system("cls");
    #endif
}

int main(){
    limpaTela();
    Funcionario *assalariado1 = new Assalariado(9000, "Shaka de Virgem", 192001);
    Funcionario *horista1 = new Horista(15, 50, "Agostinho Carrara", 5555);
    Funcionario *comissionado1 = new Comissionado(20000,25, "Abdul Adadbejar", 2332);
    SistemaGerenciaFolha system1 = SistemaGerenciaFolha(50000);//Funcionario nao encontrado
    system1.setFuncionarios(assalariado1);
    system1.setFuncionarios(horista1);
    SistemaGerenciaFolha system2 = SistemaGerenciaFolha(1000);//Estoura orcamento
    system2.setFuncionarios(assalariado1);
    system2.setFuncionarios(horista1);
    system2.setFuncionarios(comissionado1);

    std::cout << "\nConsultando salario do funcionario Abdul no system1:" << std::endl;
    try{
        system1.consultaSalarioFuncionario("Abdul");//throw no .h
        std::cout << "Salario de Abdul = " << system1.consultaSalarioFuncionario("Abdul") << " R$." << std::endl;
    }catch(FuncionarioNaoExisteException er){
        
        std::cout << "Erro " << er.getError() << " funcionario nao existe." << std::endl;
    }
    std::cout << "\nConsultando salario do funcionario Shaka no system1:" << std::endl;
    try{
        system2.consultaSalarioFuncionario("Shaka");//throw no .h
        std::cout << "Salario de Shaka = " << system2.consultaSalarioFuncionario("Shaka") << " R$." << std::endl;
    }catch(FuncionarioNaoExisteException er){
        std::cout << "Erro " << er.getError() << " funcionario nao existe." << std::endl;
    }
    ///////////////////////////////////////////////////////////////////
    std::cout << "\nCalculando valor total da folha no system2:" << std::endl;
    try{
        system2.calculaValorTotalFolha();
        std::cout << "Valor total da folha de pagamento = " << system2.calculaValorTotalFolha() << " R$." << std::endl;
    }catch(OrcamentoEstouradoException er){
        std::cout << "Erro" << er.getError() << " orcamento estourado." << std::endl;
    }
    std::cout << "\nCalculando valor total da folha no system1:" << std::endl;
    try{
        system1.calculaValorTotalFolha();
        std::cout << "Valor total da folha de pagamento = " << system1.calculaValorTotalFolha() << " R$." << std::endl;
    }catch(OrcamentoEstouradoException er){
        std::cout << "Erro" << er.getError() << " orcamento estourado." << std::endl;
    }

    return 0;
}