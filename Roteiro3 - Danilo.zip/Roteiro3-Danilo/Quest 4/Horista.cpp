#include "Horista.h"

Horista::Horista(){
    salarioPorHora = 0;
    horasTrabalhadas = 0;
}
Horista::Horista(double sph, double ht, std::string str, int mat){
    salarioPorHora = sph;
    horasTrabalhadas = ht;
    nome = str;
    matricula = mat;
}
double Horista::calculaSalario(){
    double salario;
    if(horasTrabalhadas <= 40)
        salario = salarioPorHora * horasTrabalhadas;
    else
        salario = (40 * salarioPorHora)  + ((horasTrabalhadas - 40) * (1.5*salarioPorHora));
    return salario;
}
double Horista::getSalarioPorHora(){
    return salarioPorHora;
}
double Horista::getHorasTrabalhadas(){
    return horasTrabalhadas;
}