#pragma once
#include <exception>
class OrcamentoEstouradoException
{
private:
    int error;
public:
    int getError();
    OrcamentoEstouradoException(int err);
};
