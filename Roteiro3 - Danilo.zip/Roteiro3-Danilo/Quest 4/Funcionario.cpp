#include "Funcionario.h"

Funcionario::Funcionario(){
    nome = "NULL";
    matricula = 0;
}
Funcionario::Funcionario(std::string str, int mat){
    nome = str;
    matricula = mat;
}
std::string Funcionario::getNome(){
    return nome;
}
int Funcionario::getMatricula(){
    return matricula;
}