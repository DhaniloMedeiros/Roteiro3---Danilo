#pragma once
#include "Imovel.h"

class Terreno : public Imovel
{
private:
    double area;
public:
    Terreno();
    void setArea(double ar);
    double getArea(); 
};


