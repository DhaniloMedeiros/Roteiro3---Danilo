#pragma once
#include <iostream>

class Endereco
{
private:
    std::string logradouro;
    int numero;
    std::string bairro;
    std::string cidade;
    std::string CEP;

public:
    Endereco();
    std::string getLogradouro();
    void setLogradouro(std::string log);
    int getNumero();
    void setNumero(int n);
    std::string getBairro();
    void setBairro(std::string bar);
    std::string getCidade();
    void setCidade(std::string cid);
    std::string getCEP();
    void setCEP(std::string c);
};
