#pragma once
#include "Imovel.h"

class Casa : public Imovel
{
private:
    int numPavimentos;
    int numQuartos;
    double areaTerreno;
    double areaConstruida;
public:
    Casa();
    void setNumPavimentos(int np);
    int getNumPavimentos();
    void setNumQuartos(int nq);
    int getNumQuartos();
    void setAreaTerreno(double at);
    double getAreaTerreno();
    void setAreaConstruida(double ac);
    double getAreaConstruida();
};