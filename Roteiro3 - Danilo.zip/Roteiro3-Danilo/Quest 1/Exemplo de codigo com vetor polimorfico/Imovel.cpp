#include "Imovel.h"
#include <algorithm>

Imovel::Imovel(){
    Endereco end;
    indice = 0;
    valor = 0;
    tipoOferta = 0;
    IMOVEL_PARA_VENDER  = false;
    IMOVEL_PARA_ALUGAR  = false;
    endereco = end;
    descricao = "NULL";
}
int Imovel::getValor(){
    return valor;
}
void Imovel::setValor(double v){
    if(v >= 0)
        valor = v;
    else
        valor = 0;
}
int Imovel::getTipoOferta(){
    return tipoOferta;
}
void Imovel::setTipoOferta(int tipo){
    if(tipo > 0 && tipo <= 3){
        tipoOferta = tipo;
    }
    else
        tipoOferta = 0;
}

Endereco Imovel::getEndereco(){
    return endereco;
}
void Imovel::setEndereco(Endereco end){
    endereco = end;
}
std::string Imovel::getDescricao(){
    return descricao;
}
void Imovel::setDescricao(std::string str){
    std::transform(str.begin(), str.end(),str.begin(), ::toupper);
    descricao = str;
}
bool Imovel::getTipoDeContrato(){
    if(IMOVEL_PARA_ALUGAR)
        return true;//true pra aluguel
    else
        return false;//false pra venda
}
void Imovel::setTipoDeContrato(bool cont){
    if(cont){
        IMOVEL_PARA_ALUGAR = true;
        IMOVEL_PARA_VENDER = false;
    }
    else{
        IMOVEL_PARA_VENDER = true;
        IMOVEL_PARA_ALUGAR = false;
    }
}

int Imovel::getIndice(){
    return indice;
}

void Imovel::setIndice(int i){
    indice = i;
}