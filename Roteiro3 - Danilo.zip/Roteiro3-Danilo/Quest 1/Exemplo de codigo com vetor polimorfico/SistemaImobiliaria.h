#pragma once
#include <vector>
#include <fstream>
#include "Apartamento.h"
#include "Casa.h"
#include "Terreno.h"

class SistemaImobiliaria
{
private:
    std::vector<Imovel*> imoveis;
public:
    SistemaImobiliaria();
    void cadastraApartamento(Apartamento* imv);
    void cadastraCasa(Casa* imv);
    void cadastraTerreno(Terreno* imv);
    
    void setImoveis(std::vector<Imovel*> imv);
    std::vector<Imovel*> getImoveis();
    std::vector<std::string> getDescricaoImoveis();
    std::vector<Imovel*> getImoveisPorTipo(int tipo);
    std::vector<Imovel*> getImoveisPorCidade(std::string str);
    std::vector<Imovel*> getImoveisPorDescricao(std::string str);
    std::vector<Imovel*> getImoveisPorBairro(std::string str);
    std::vector<Imovel*> getImoveisPorValor(double precoAlvo, bool maior_menor);//true maior, false menor

    void removerImovel(int index);
    void editarApartamento(int index, Apartamento* im);
    void editarCasa(int index, Casa* im);
    void editarTerreno(int index, Terreno* im);
};
