#include <iostream>
#include <string>
#include <algorithm>


int main(){
    std::string j, k;
    j = "jam";
    std::cout << j << "kakakaka";
    std::transform(j.begin(), j.end(),j.begin(), ::toupper);
    std::cout << j << "KKKKKKKK";
    return 0;
}