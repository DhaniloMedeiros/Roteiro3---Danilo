#pragma once
#include "Imovel.h"
#include <iostream>

class Apartamento : public Imovel
{
private:
    std::string posicao;
    int numQuartos;
    double valorCondominio;
    int vagasGaragem;  
    double area;
public:
    Apartamento();
    void setPosicao(std::string str);
    void setNumQuartos(int nq);
    void setValorCondominio(double vc);
    void setVagasGaragem(int vg);
    void setArea(double ar);
    std::string getPosicao();
    int getNumQuartos();
    double getValorCondominio();
    int getVagasGaragem();
    double getArea();
};
