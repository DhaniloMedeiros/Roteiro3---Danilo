#include "Terreno.h"
#include <algorithm>

Terreno::Terreno(){
    setTipoOferta(3);
    area = 0;
}
void Terreno::setArea(double ar){
    if(ar >= 0)
        area = ar;
    else
        area = 0;
}
double Terreno::getArea(){
    return area;
}