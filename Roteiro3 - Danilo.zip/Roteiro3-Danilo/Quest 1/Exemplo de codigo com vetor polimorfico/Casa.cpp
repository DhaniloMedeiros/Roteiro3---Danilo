#include "Casa.h"
#include <algorithm>

Casa::Casa(){
    setTipoOferta(2);
    numPavimentos = 0;
    numQuartos = 0;
    areaConstruida = 0;
    areaTerreno = 0;
} 
void Casa::setNumPavimentos(int np){
    if(np >= 0)
        numPavimentos = np;
    else 
        numPavimentos = 0;
}
int Casa::getNumPavimentos(){
    return numPavimentos;
}
void Casa::setNumQuartos(int nq){
    if(nq >= 0)
        numQuartos = nq;
    else
        numQuartos = 0;
}
int Casa::getNumQuartos(){
    return numQuartos;
}
void Casa::setAreaTerreno(double at){
    if(at >= 0)
        areaTerreno = at;
    else
        areaTerreno = 0;
}
double Casa::getAreaTerreno(){
    return areaTerreno;
}
void Casa::setAreaConstruida(double ac){
    if(ac >= 0)
        areaConstruida = ac;
    else
        areaConstruida = 0;
}
double Casa::getAreaConstruida(){
    return areaConstruida;
}