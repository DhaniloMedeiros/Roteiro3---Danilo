#include "Endereco.h"
#include <algorithm>

Endereco::Endereco(){
    setBairro("NULL");
    setLogradouro("NULL");
    setNumero(0);
    setCEP("NULL");
    setCidade("NULL");
}
std::string Endereco::getLogradouro(){
    return logradouro;
}
void Endereco::setLogradouro(std::string log){
    std::transform(log.begin(), log.end(),log.begin(), ::toupper);
    logradouro = log;
}
int Endereco::getNumero(){
    return numero;
}
void Endereco::setNumero(int n){
    if(n >= 0)
        numero = n;
    else
        numero = 0;
}
std::string Endereco::getBairro(){
    return bairro;
}
void Endereco::setBairro(std::string bar){
    std::transform(bar.begin(), bar.end(),bar.begin(), ::toupper);
    bairro = bar;
}
std::string Endereco::getCidade(){
    return cidade;
}
void Endereco::setCidade(std::string cid){
    std::transform(cid.begin(), cid.end(),cid.begin(), ::toupper);
    cidade = cid;
}
std::string Endereco::getCEP(){
    return CEP;
}
void Endereco::setCEP(std::string c){
    std::transform(c.begin(), c.end(),c.begin(), ::toupper);
    CEP = c;
}