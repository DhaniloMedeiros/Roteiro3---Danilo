#pragma once
#include "Endereco.h"
#include <iostream> 

class Imovel
{
private:
    int indice;
    int tipoOferta; //1 = apartamento, 2 = casa, 3 = terreno
    bool IMOVEL_PARA_VENDER;
    bool IMOVEL_PARA_ALUGAR;
    double valor;
    Endereco endereco;
    std::string descricao;
public:
    Imovel();
    int getValor();
    void setValor(double v);
    int getTipoOferta();
    void setTipoOferta(int tipo);
    Endereco getEndereco();
    void setEndereco(Endereco end);
    std::string getDescricao();
    void setDescricao(std::string str);
    bool getTipoDeContrato();
    void setTipoDeContrato(bool cont);
    int getIndice();
    void setIndice(int i);
};
