#include "Apartamento.h"
#include <algorithm>

Apartamento::Apartamento(){
    setTipoOferta(1);
    posicao = "NULL";
    numQuartos = 0;
    valorCondominio = 0;
    vagasGaragem = 0;
    area = 0;
}
void Apartamento::setPosicao(std::string str){
    std::transform(str.begin(), str.end(),str.begin(), ::toupper);
    posicao = str;
}
void Apartamento::setNumQuartos(int nq){
    if(nq >= 0)
        numQuartos = nq;
    else
        numQuartos = 0;
}
void Apartamento::setValorCondominio(double vc){
    if(vc >= 0)
        valorCondominio = vc;
    else
        valorCondominio = 0;
}
void Apartamento::setVagasGaragem(int vg){
    if(vg >= 0)
        vagasGaragem = vg;
    else
        vagasGaragem = 0;
}
void Apartamento::setArea(double ar){
    if(ar >= 0)
        area = ar;
    else
        area = 0;
}
std::string Apartamento::getPosicao(){
    return posicao;
}
int Apartamento::getNumQuartos(){
    return numQuartos;
}
double Apartamento::getValorCondominio(){
    return valorCondominio;
}
int Apartamento::getVagasGaragem(){
    return vagasGaragem;
}
double Apartamento::getArea(){
    return area;
}