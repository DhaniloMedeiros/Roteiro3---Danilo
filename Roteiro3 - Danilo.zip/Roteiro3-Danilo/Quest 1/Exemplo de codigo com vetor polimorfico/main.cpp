#include "SistemaImobiliaria.h"

void limpaTela(void){
    #ifdef __unix__
        system("clear");
    #elif WIN32
        system("cls" ;
    #endif
}
std::vector<Imovel*> lerArquivo(){
    std::ifstream arquivoImobiliaria;
    std::vector<Imovel*> vetorRetornado;

    arquivoImobiliaria.open("imoveis.txt");
    std::string str;
    double db;
    int it;
    Apartamento* auxAP = new Apartamento();
    Casa* auxCS = new Casa();
    Terreno* auxTR = new Terreno();
    Endereco auxED;

    if(!arquivoImobiliaria.is_open()){
        std::cout << "Nao foi possivel abrir o arquivo.";
        return vetorRetornado;
    }
    while (true){
        if (arquivoImobiliaria.eof() || arquivoImobiliaria.bad() || arquivoImobiliaria.fail())
            break;
        arquivoImobiliaria >> it;
        if(it == 1){
            arquivoImobiliaria >> it;
            arquivoImobiliaria.ignore();
            auxAP->setIndice(it);
            getline(arquivoImobiliaria, str);
            if(str == "aluguel")
                auxAP->setTipoDeContrato(true);
            else
                auxAP->setTipoDeContrato(false);
            arquivoImobiliaria >> db;
            arquivoImobiliaria.ignore();
            auxAP->setValor(db);
            getline(arquivoImobiliaria, str);
            auxAP->setDescricao(str);
            getline(arquivoImobiliaria, str);
            auxED.setBairro(str);
            getline(arquivoImobiliaria, str);
            auxED.setCidade(str);
            getline(arquivoImobiliaria, str);
            auxED.setCEP(str);
            getline(arquivoImobiliaria, str);
            auxED.setLogradouro(str);
            arquivoImobiliaria >> it;
            arquivoImobiliaria.ignore();
            auxED.setNumero(it);
            auxAP->setEndereco(auxED);
            //****
            getline(arquivoImobiliaria, str);
            auxAP->setPosicao(str);
            arquivoImobiliaria >> it;
            auxAP->setNumQuartos(it);
            arquivoImobiliaria >> db;
            auxAP->setValorCondominio(db);
            arquivoImobiliaria >> it;
            auxAP->setVagasGaragem(it);
            arquivoImobiliaria >> db;
            auxAP->setArea(db);
            vetorRetornado.push_back(auxAP);
        }else if(it == 2){
            arquivoImobiliaria >> it;
            arquivoImobiliaria.ignore();
            auxCS->setIndice(it);
            getline(arquivoImobiliaria, str);
            if(str == "aluguel")
                auxCS->setTipoDeContrato(true);
            else
                auxCS->setTipoDeContrato(false);
            arquivoImobiliaria >> db;
            arquivoImobiliaria.ignore();
            auxCS->setValor(db);
            getline(arquivoImobiliaria, str);
            auxCS->setDescricao(str);
            getline(arquivoImobiliaria, str);
            auxED.setBairro(str);
            getline(arquivoImobiliaria, str);
            auxED.setCidade(str);
            getline(arquivoImobiliaria, str);
            auxED.setCEP(str);
            getline(arquivoImobiliaria, str);
            auxED.setLogradouro(str);
            arquivoImobiliaria >> it;
            auxED.setNumero(it);
            auxCS->setEndereco(auxED);
            //****
            arquivoImobiliaria >> it;
            auxCS->setNumQuartos(it);
            arquivoImobiliaria >> it;
            auxCS->setNumPavimentos(it);
            arquivoImobiliaria >> db;
            auxCS->setAreaTerreno(db);
            arquivoImobiliaria >> db;
            auxCS->setAreaConstruida(db);
            vetorRetornado.push_back(auxCS);
        }else if(it == 3){
            arquivoImobiliaria >> it;
            arquivoImobiliaria.ignore();
            auxTR->setIndice(it);
            getline(arquivoImobiliaria, str);
            if(str == "aluguel")
                auxTR->setTipoDeContrato(true);
            else
                auxTR->setTipoDeContrato(false);
            arquivoImobiliaria >> db;
            arquivoImobiliaria.ignore();
            auxTR->setValor(db);
            getline(arquivoImobiliaria, str);
            auxTR->setDescricao(str);
            getline(arquivoImobiliaria, str);
            auxED.setBairro(str);
            getline(arquivoImobiliaria, str);
            auxED.setCidade(str);
            getline(arquivoImobiliaria, str);
            auxED.setCEP(str);
            getline(arquivoImobiliaria, str);
            auxED.setLogradouro(str);
            arquivoImobiliaria >> it;
            auxED.setNumero(it);
            auxTR->setEndereco(auxED);
            //****
            arquivoImobiliaria >> db;
            auxTR->setArea(db);
            vetorRetornado.push_back(auxTR);
        }   
    }
    arquivoImobiliaria.close();
    return vetorRetornado;
}
void salvarArquivo(std::vector<Imovel*> vector){
    std::ofstream arquivoImobiliaria;
    Endereco end;
    Apartamento *auxAP = new Apartamento();
    Casa *auxCS = new Casa();
    Terreno *auxTR = new Terreno();
    
    arquivoImobiliaria.open("imoveis.txt");
    if(!arquivoImobiliaria.is_open()){
        std::cout << "Nao foi possivel abrir o arquivo.";
        return;
    }

    for(int i = 0; i < vector.size(); i++){
        if(vector[i]->getTipoOferta() == 1){//apartamento
            auxAP = (Apartamento*)vector[i];
            arquivoImobiliaria << vector[i]->getTipoOferta() << std::endl;
            arquivoImobiliaria << vector[i]->getIndice() << std::endl;
            if(vector[i]->getTipoDeContrato())
                arquivoImobiliaria << "aluguel" << std::endl;
            else
                arquivoImobiliaria << "venda" << std::endl;
            arquivoImobiliaria << vector[i]->getValor() << std::endl;
            arquivoImobiliaria << vector[i]->getDescricao() << std::endl;  
            end = vector[i]->getEndereco();
            arquivoImobiliaria << end.getBairro() << std::endl;
            arquivoImobiliaria << end.getCidade() << std::endl;
            arquivoImobiliaria << end.getCEP() << std::endl;
            arquivoImobiliaria << end.getLogradouro() << std::endl;
            arquivoImobiliaria << end.getNumero() << std::endl;
            //****
            arquivoImobiliaria << auxAP->getPosicao() << std::endl;
            arquivoImobiliaria << auxAP->getNumQuartos() << std::endl;
            arquivoImobiliaria << auxAP->getValorCondominio() << std::endl;
            arquivoImobiliaria << auxAP->getVagasGaragem() << std::endl; 
            arquivoImobiliaria << auxAP->getArea() << std::endl;
        }else if(vector[i]->getTipoOferta() == 2){//casa
            auxCS = (Casa*)vector[i];
            arquivoImobiliaria << vector[i]->getTipoOferta() << std::endl;
            arquivoImobiliaria << vector[i]->getIndice() << std::endl;
            if(vector[i]->getTipoDeContrato())
                arquivoImobiliaria << "aluguel" << std::endl;
            else
                arquivoImobiliaria << "venda" << std::endl;
            arquivoImobiliaria << vector[i]->getValor() << std::endl;
            arquivoImobiliaria << vector[i]->getDescricao() << std::endl;  
            end = vector[i]->getEndereco();
            arquivoImobiliaria << end.getBairro() << std::endl;
            arquivoImobiliaria << end.getCidade() << std::endl;
            arquivoImobiliaria << end.getCEP() << std::endl;
            arquivoImobiliaria << end.getLogradouro() << std::endl;
            arquivoImobiliaria << end.getNumero() << std::endl;
            //****
            arquivoImobiliaria << auxCS->getNumQuartos() << std::endl;
            arquivoImobiliaria << auxCS->getNumPavimentos() << std::endl;
            arquivoImobiliaria << auxCS->getAreaTerreno() << std::endl;
            arquivoImobiliaria << auxCS->getAreaConstruida() << std::endl;
        }else if(vector[i]->getTipoOferta() == 3){//terreno
            auxTR = (Terreno*)vector[i];
            arquivoImobiliaria << vector[i]->getTipoOferta() << std::endl;
            arquivoImobiliaria << vector[i]->getIndice() << std::endl;
            if(vector[i]->getTipoDeContrato())
                arquivoImobiliaria << "aluguel" << std::endl;
            else
                arquivoImobiliaria << "venda" << std::endl;
            arquivoImobiliaria << vector[i]->getValor() << std::endl;
            arquivoImobiliaria << vector[i]->getDescricao() << std::endl;  
            end = vector[i]->getEndereco();
            arquivoImobiliaria << end.getBairro() << std::endl;
            arquivoImobiliaria << end.getCidade() << std::endl;
            arquivoImobiliaria << end.getCEP() << std::endl;
            arquivoImobiliaria << end.getLogradouro() << std::endl;
            arquivoImobiliaria << end.getNumero() << std::endl;
            //****
            arquivoImobiliaria << auxTR->getArea() << std::endl;
        }
    }
    arquivoImobiliaria.close();
}
void exibeMenu(){
    puts("\n~~~~~~~~~~~~~~~~~~IMOBILIARIA CHICO TRIPA~~~~~~~~~~~~~~~~~~");
    puts("(1-Cadastrar Imoveis)");
    puts("(2-Consultar Imoveis)");
    puts("(3-Buscar Imoveis)");
    puts("(4-Salvar alteracoes e sair)");
    puts("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    std::cout << "Digite o nº da opcao desejada: ";
}
void menuCadastro(){
    puts("\n~~~~~~~~CADASTRANDO IMOVEIS~~~~~~~~");
    puts("(1-Cadastrar Apartamento)");
    puts("(2-Cadastrar Casa)");
    puts("(3-Cadastrar Terreno)");
    puts("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    std::cout << "Digite o nº da opcao desejada: ";
}
void menuBusca(){
    puts("\n~~~~~~~~BUSCANDO IMOVEIS~~~~~~~~");
    puts("É possível remover ou editar o imovel encontrado.");
    puts("(1-Busca por tipo)");//tipo, cidade, descricao, bairro, valor+-
    puts("(2-Busca por cidade)");
    puts("(3-Busca por descricao)");
    puts("(4-Busca por bairro)");
    puts("(5-Busca por valor)");
    puts("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    std::cout << "Digite o nº da opcao desejada: ";
}
void buscaTipo(){
    puts("\n~~~~~~~~BUSCANDO IMOVEIS~~~~~~~~");
    puts("(1-Buscar Apartamentos)");
    puts("(2-Buscar Casas)");
    puts("(3-Buscar Terrenos)");    
    puts("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    std::cout << "Digite o nº da opcao desejada: ";
}
void buscaValor(){
    puts("\n~~~~~~~~BUSCA POR VALOR~~~~~~~~");
    puts("(1-Buscar acima desse valor)");
    puts("(2-Buscar abaixo desse valor)");
    puts("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    std::cout << "Digite o nº da opcao desejada: ";
}
void menuRMV(){
    puts("\n\n(1-Remover imovel)");
    puts("(2-Modificar imovel)");
    puts("(3-Voltar ao menu)");
    puts("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    std::cout << "Digite o nº da opcao desejada: ";
}
Endereco cadastraEndereco(){
    Endereco end;
    int auxInt;
    std::string str;
    std::cout << "Digite o logradouro: ";
    getline(std::cin, str);
    end.setLogradouro(str);
    std::cout << "Digite o numero: ";
    std::cin >> auxInt;
    end.setNumero(auxInt);
    getchar();
    std::cout << "Digite o bairro: ";
    getline(std::cin, str);
    end.setBairro(str);
    std::cout << "Digite a cidade: ";
    getline(std::cin, str);
    end.setCidade(str);
    std::cout << "Digite o CEP: ";
    getline(std::cin, str); 
    end.setCEP(str);
    
    return end;
}
Apartamento* cadastraApartamento(){
    Apartamento* im = new Apartamento();
    int auxInt;
    double auxDb;
    std::string str;
    puts("\n~~~~~Cadastrando Apartamento~~~~~\n");
    std::cout << "Digite 1 para alugar o imovel e 2 para vender: ";
    std::cin >> auxInt;
    getchar();
    if(auxInt == 1)
        im->setTipoDeContrato(true);
    else
        im->setTipoDeContrato(false);
    std::cout << "Digite o valor do imovel: ";
    std::cin >> auxDb;
    getchar();
    im->setValor(auxDb);
    im->setEndereco(cadastraEndereco());
    std::cout << "Digite a descricao do imovel: ";
    getline(std::cin, str);
    im->setDescricao(str);
    std::cout << "Digite a posicao do imovel: ";
    getline(std::cin, str);
    im->setPosicao(str);
    std::cout << "Digite o nº de quartos do imovel: ";
    std::cin >> auxInt;
    getchar();
    im->setNumQuartos(auxInt);
    std::cout << "Digite o valor do condominio: ";
    std::cin >> auxDb;
    getchar();
    im->setValorCondominio(auxDb);
    std::cout << "Digite o nº de vagas de garagem: ";
    std::cin >> auxInt;
    getchar();
    im->setVagasGaragem(auxInt);
    std::cout << "Digite a area do imovel: ";
    std::cin >> auxDb;
    getchar();
    im->setArea(auxDb);
    
    return im;
}
Casa* cadastraCasa(){
    Casa* im = new Casa();
    int auxInt;
    double auxDb;
    std::string str;
    puts("\n~~~~~Cadastrando Casa~~~~~\n");
    std::cout << "Digite 1 para alugar o imovel e 2 para vender: ";
    std::cin >> auxInt;
    getchar();
    if(auxInt == 1)
        im->setTipoDeContrato(true);
    else
        im->setTipoDeContrato(false);
    std::cout << "Digite o valor do imovel: ";
    std::cin >> auxDb;
    getchar();
    im->setValor(auxDb);
    im->setEndereco(cadastraEndereco());
    std::cout << "Digite a descricao do imovel: ";
    getline(std::cin, str);
    im->setDescricao(str); 
    std::cout << "Digite o numero de pavimentos: ";
    std::cin >> auxInt;
    getchar();
    im->setNumPavimentos(auxInt);
    std::cout << "Digite o numero de quartos: ";
    std::cin >> auxInt;
    getchar();
    im->setNumQuartos(auxInt);
    std::cout << "Digite a area do terreno: ";
    std::cin >> auxDb;
    getchar();
    im->setAreaTerreno(auxDb);
    std::cout << "Digite a area construida: ";
    std::cin >> auxDb;
    getchar();
    im->setAreaConstruida(auxDb);

    return im;
}
Terreno* cadastraTerreno(){
    Terreno* im = new Terreno();
    int auxInt;
    double auxDb;
    std::string str;
    puts("\n~~~~~Cadastrando Terreno~~~~~\n");
    std::cout << "Digite 1 para alugar o imovel e 2 para vender: ";
    std::cin >> auxInt;
    getchar();
    if(auxInt == 1)
        im->setTipoDeContrato(true);
    else
        im->setTipoDeContrato(false);
    std::cout << "Digite o valor do imovel: ";
    std::cin >> auxDb;
    getchar();
    im->setValor(auxDb);
    im->setEndereco(cadastraEndereco());
    std::cout << "Digite a descricao do imovel: ";
    getline(std::cin, str);
    im->setDescricao(str);
    std::cout << "Digite a area do imovel: ";
    std::cin >> auxDb;
    getchar();
    im->setArea(auxDb);

    return im;
}
void printApartamento(Apartamento* im){
    Endereco auxEnd;
    std::cout << im->getIndice() << "]" << std::endl;
    std::cout << im->getDescricao() << std::endl;
    if(im->getTipoDeContrato())
        std::cout << "O imovel esta disponivel para aluguel por "<< im->getValor() << "R$ mensais" << std::endl;
    else 
        std::cout << "O imovel esta a venda por " << im->getValor() << "R$" << std::endl;
    auxEnd = im->getEndereco();
    std::cout << "Endereco do imovel:" << std::endl;
    std::cout << "Logradouro: " << auxEnd.getLogradouro() << std::endl;
    std::cout << "Numero: " << auxEnd.getNumero() << std::endl;
    std::cout << "Cidade: " <<auxEnd.getCidade() << std::endl;
    std::cout << "Bairro: " << auxEnd.getBairro() << std::endl;
    std::cout << "CEP: " << auxEnd.getCEP() << std::endl;
    std::cout << "Area: " << im->getArea() << "m²"<< std::endl;
    std::cout << "Posicao do Apartamento: " << im->getPosicao() << std::endl;
    std::cout << "Numero de quartos: " << im->getNumQuartos() << std::endl;
    std::cout << "Numero de vagas de garagem: " << im->getVagasGaragem() << std::endl;
    std::cout << "Valor do condominio: " << im->getValorCondominio() << "R$" << std::endl;
}
void printCasa(Casa* im){
    Endereco auxEnd;
    std::cout << im->getIndice() << "]" << std::endl;
    std::cout << im->getDescricao() << std::endl;
    if(im->getTipoDeContrato())
        std::cout << "O imovel esta disponivel para aluguel por "<< im->getValor() << "R$ mensais" << std::endl;
    else 
        std::cout << "O imovel esta a venda por " << im->getValor() << "R$" << std::endl;
    auxEnd = im->getEndereco();
    std::cout << "Endereco do imovel:" << std::endl;
    std::cout << "Logradouro: " << auxEnd.getLogradouro() << std::endl;
    std::cout << "Numero: " << auxEnd.getNumero() << std::endl;
    std::cout << "Cidade: " <<auxEnd.getCidade() << std::endl;
    std::cout << "Bairro: " << auxEnd.getBairro() << std::endl;
    std::cout << "CEP: " << auxEnd.getCEP() << std::endl;
    std::cout << "Area do terreno: " << im->getAreaTerreno() << "m²" << std::endl;
    std::cout << "Area construida: " << im->getAreaConstruida() << "m²" << std::endl;
    std::cout << "Numero de pavimentos: " << im->getNumPavimentos() << std::endl;
    std::cout << "Numero de quartos: " << im->getNumQuartos() << std::endl;

}
void printTerreno(Terreno* im){
    Endereco auxEnd;
    std::cout << im->getIndice() << "]" << std::endl;
    std::cout << im->getDescricao() << std::endl;
    if(im->getTipoDeContrato())
        std::cout << "O imovel esta disponivel para aluguel por "<< im->getValor() << "R$ mensais." << std::endl;
    else 
        std::cout << "O imovel esta a venda por " << im->getValor() << "R$." << std::endl;
    auxEnd = im->getEndereco();
    std::cout << "Endereco do imovel:" << std::endl;
    std::cout << "Logradouro: " << auxEnd.getLogradouro() << std::endl;
    std::cout << "Numero: " << auxEnd.getNumero() << std::endl;
    std::cout << "Cidade: " <<auxEnd.getCidade() << std::endl;
    std::cout << "Bairro: " << auxEnd.getBairro() << std::endl;
    std::cout << "CEP: " << auxEnd.getCEP() << std::endl;
    std::cout << "Area do terreno: " << im->getArea() << "m²" << std::endl;
}
void printVetorImoveis(std::vector<Imovel*> vetor){
    size_t tam = vetor.size();
    Apartamento* auxAP = new Apartamento();
    Casa *auxCS = new Casa();
    Terreno *auxTR = new Terreno();
    int i;
    for(i = 0; i < tam; i++){
        if(vetor[i]->getTipoOferta() == 1){
            std::cout << "\nApartamento [indice: ";//completa no print(imovel)
            auxAP = (Apartamento*)vetor[i];
            printApartamento(auxAP);
        }else if(vetor[i]->getTipoOferta() == 2){
            std::cout << "\nCasa [indice: ";
            auxCS = (Casa*)vetor[i];
            printCasa(auxCS);
        }else if(vetor[i]->getTipoOferta() == 3){
            std::cout << "\nTerreno [indice: ";
            auxTR = (Terreno*)vetor[i];
            printTerreno(auxTR);
        }
    }
}
int main(){
    int opcao;
    bool loop = true;
    Apartamento *auxAP = new Apartamento();
    Casa *auxCS = new Casa();
    Terreno *auxTR = new Terreno();
    SistemaImobiliaria imobiliariaChico;
    imobiliariaChico.setImoveis(lerArquivo());
    std::vector<Imovel*> vetorChico = imobiliariaChico.getImoveis();
    

    while(loop){
        std::string str;
        double db;
        int it;
        limpaTela();
        exibeMenu();
        std::cin >> opcao;
        getchar();
        switch(opcao)
        {
            case 1://cadastro
                limpaTela();
                menuCadastro();
                std::cin >> opcao;
                getchar();
                switch(opcao)
                {
                    case 1://cadastrando apartamento
                        limpaTela();
                        auxAP = cadastraApartamento();
                        imobiliariaChico.cadastraApartamento(auxAP);
                        std::cout << "\nCadastro finalizado, aperte ENTER.";
                        getchar();
                        break;
                    case 2://cadastrando casa
                        limpaTela();
                        auxCS = cadastraCasa();
                        imobiliariaChico.cadastraCasa(auxCS);
                        std::cout << "\nCadastro finalizado, aperte ENTER.";
                        getchar();
                        break;
                    case 3://cadastrando terreno
                        limpaTela();
                        auxTR = cadastraTerreno();
                        imobiliariaChico.cadastraTerreno(auxTR);
                        std::cout << "\nCadastro finalizado, aperte ENTER.";
                        getchar();
                        break;
                    default:
                        limpaTela();
                        std::cout << "Opcao invalida, aperte ENTER.";
                        getchar();
                        break;
                }
                break;
            case 2://consultar imoveis
                limpaTela();
                std::cout << "~~~~~~Imoveis Disponives~~~~~~";
                printVetorImoveis(imobiliariaChico.getImoveis());
                std::cout << "\nAperte ENTER, para voltar ao menu.";
                getchar();
                break;
            case 3://Buscar imoveis
                limpaTela();
                menuBusca();
                std::cin >> opcao;
                getchar();
                switch (opcao)
                {
                    case 1://busca tipo
                        limpaTela();
                        buscaTipo();
                        std::cin >> opcao;
                        getchar();
                        switch (opcao)
                        {
                            case 1://ap
                                limpaTela();
                                std::cout << "~~~~~~Imoveis Disponives~~~~~~";
                                printVetorImoveis(imobiliariaChico.getImoveisPorTipo(1));
                                menuRMV();
                                std::cin >> opcao;
                                getchar();
                                switch (opcao)
                                {
                                    case 1://remover
                                        limpaTela();
                                        printVetorImoveis(imobiliariaChico.getImoveisPorTipo(1));
                                        std::cout << "\nDigite o indice do imovel que deseja remover: ";
                                        std::cin >> it;;
                                        getchar();
                                        imobiliariaChico.removerImovel(it);
                                        std::cout << "\nRemocao finalizada, aperte ENTER.";
                                        getchar();
                                        break;
                                    case 2://modificar
                                        limpaTela();
                                        printVetorImoveis(imobiliariaChico.getImoveisPorTipo(1));
                                        std::cout << "\nDigite o indice do imovel que deseja recadastrar: ";
                                        std::cin >> it;
                                        getchar();
                                        imobiliariaChico.editarApartamento(it, cadastraApartamento());
                                        std::cout << "\nEdicao finalizada, aperte ENTER.";
                                        getchar();
                                        break;
                                    case 3://vazar
                                        limpaTela();
                                        break;
                                    default:
                                        limpaTela();
                                        std::cout << "Opcao invalida, aperte ENTER.";
                                        getchar();
                                        break;
                                }
                                break;
                            case 2://casa
                                limpaTela();
                                std::cout << "~~~~~~Imoveis Disponives~~~~~~";
                                printVetorImoveis(imobiliariaChico.getImoveisPorTipo(2));
                                menuRMV();
                                std::cin >> opcao;
                                getchar();
                                switch (opcao)
                                {
                                    case 1://remover
                                        limpaTela();
                                        printVetorImoveis(imobiliariaChico.getImoveisPorTipo(2));
                                        std::cout << "\nDigite o indice do imovel que deseja remover: ";
                                        std::cin >> it;
                                        getchar();
                                        imobiliariaChico.removerImovel(it);
                                        std::cout << "\nRemocao finalizada, aperte ENTER.";
                                        getchar();
                                        break;
                                    case 2://modificar
                                        limpaTela();
                                        printVetorImoveis(imobiliariaChico.getImoveisPorTipo(2));
                                        std::cout << "\nDigite o indice do imovel que deseja recadastrar: ";
                                        std::cin >> it;
                                        getchar();
                                        imobiliariaChico.editarCasa(it, cadastraCasa());
                                        std::cout << "\nEdicao finalizada, aperte ENTER.";
                                        getchar();
                                        break;
                                    case 3://vazar
                                        limpaTela();
                                        break;
                                    default:
                                        limpaTela();
                                        std::cout << "Opcao invalida, aperte ENTER.";
                                        getchar();
                                        break;
                                }
                                break;
                            case 3://terreno
                                limpaTela();
                                std::cout << "~~~~~~Imoveis Disponives~~~~~~";
                                printVetorImoveis(imobiliariaChico.getImoveisPorTipo(3));
                                menuRMV();
                                std::cin >> opcao;
                                getchar();
                                switch (opcao)
                                {
                                    case 1://remover
                                        limpaTela();
                                        printVetorImoveis(imobiliariaChico.getImoveisPorTipo(3));
                                        std::cout << "Digite o indice do imovel que deseja remover: ";
                                        std::cin >> it;
                                        getchar();
                                        imobiliariaChico.removerImovel(it);
                                        std::cout << "\nRemocao finalizada, aperte ENTER.";
                                        getchar();
                                        break;
                                    case 2://modificar
                                        limpaTela();
                                        printVetorImoveis(imobiliariaChico.getImoveisPorTipo(3));
                                        std::cout << "Digite o indice do imovel que deseja recadastrar: ";
                                        std::cin >> it;
                                        getchar();
                                        imobiliariaChico.editarTerreno(it, cadastraTerreno());
                                        std::cout << "\nEdicao finalizada, aperte ENTER.";
                                        getchar();
                                        break;
                                    case 3://vazar
                                        limpaTela();
                                        break;
                                    default:
                                        limpaTela();
                                        std::cout << "Opcao invalida, aperte ENTER.";
                                        getchar();
                                        break;
                                }
                                break;
                            default://terr
                                limpaTela();
                                std::cout << "Opcao invalida, aperte ENTER.";
                                getchar();
                                break;
                        }
                        break;
                    case 2://busca cidade
                        limpaTela();
                        std::cout << "Digite a cidade desejada: ";
                        getline(std::cin, str);
                        std::cout << "~~~~~~Imoveis Disponives~~~~~~";
                        printVetorImoveis(imobiliariaChico.getImoveisPorCidade(str));
                        menuRMV();
                        std::cin >> opcao;
                        getchar();
                        switch (opcao)
                        {
                            case 1://remover
                                limpaTela();
                                printVetorImoveis(imobiliariaChico.getImoveisPorCidade(str));
                                std::cout << "\nDigite o indice do imovel que deseja remover: ";
                                std::cin >> it;
                                getchar();
                                imobiliariaChico.removerImovel(it);
                                std::cout << "\nRemocao finalizada, aperte ENTER.";
                                getchar();
                                break;
                            case 2://modificar
                                limpaTela();
                                printVetorImoveis(imobiliariaChico.getImoveisPorCidade(str));
                                std::cout << "\nDigite o indice do imovel que deseja recadastrar: ";
                                std::cin >> it;
                                getchar();
                                if(vetorChico[it-1]->getTipoOferta() == 1){
                                    imobiliariaChico.editarApartamento(it, cadastraApartamento());
                                }else if(vetorChico[it-1]->getTipoOferta() == 2){
                                    imobiliariaChico.editarCasa(it, cadastraCasa());
                                }else if(vetorChico[it-1]->getTipoOferta() == 3){
                                    imobiliariaChico.editarTerreno(it, cadastraTerreno());
                                }
                                std::cout << "\nEdicao finalizada, aperte ENTER.";
                                getchar();
                                break;
                            case 3://vazar
                                limpaTela();
                                break;
                            default:
                                limpaTela();
                                std::cout << "Opcao invalida, aperte ENTER.";
                                getchar();
                                break;
                        }
                        break;
                    case 3://busca descricao
                        limpaTela();
                        std::cout << "Digite a descricao desejada: ";
                        getline(std::cin, str);
                        std::cout << "~~~~~~Imoveis Disponives~~~~~~";
                        printVetorImoveis(imobiliariaChico.getImoveisPorDescricao(str));
                        menuRMV();
                        std::cin >> opcao;
                        getchar();
                        switch (opcao)
                        {
                            case 1://remover
                                limpaTela();
                                printVetorImoveis(imobiliariaChico.getImoveisPorDescricao(str));
                                std::cout << "\nDigite o indice do imovel que deseja remover: ";
                                std::cin >> it;
                                getchar();
                                imobiliariaChico.removerImovel(it);
                                std::cout << "\nRemocao finalizada, aperte ENTER.";
                                getchar();
                                break;
                            case 2://modificar
                                limpaTela();
                                printVetorImoveis(imobiliariaChico.getImoveisPorDescricao(str));
                                std::cout << "\nDigite o indice do imovel que deseja recadastrar: ";
                                std::cin >> it;
                                getchar();
                                if(vetorChico[it-1]->getTipoOferta() == 1){
                                    imobiliariaChico.editarApartamento(it, cadastraApartamento());
                                }else if(vetorChico[it-1]->getTipoOferta() == 2){
                                    imobiliariaChico.editarCasa(it, cadastraCasa());
                                }else if(vetorChico[it-1]->getTipoOferta() == 3){
                                    imobiliariaChico.editarTerreno(it, cadastraTerreno());
                                }
                                std::cout << "\nEdicao finalizada, aperte ENTER.";
                                getchar();
                                break;
                            case 3://vazar
                                limpaTela();
                                break;
                            default:
                                limpaTela();
                                std::cout << "Opcao invalida, aperte ENTER.";
                                getchar();
                                break;
                        }
                        break;
                    case 4://busca bairro
                        limpaTela();
                        std::cout << "Digite o bairro desejado: ";
                        getline(std::cin, str);
                        std::cout << "~~~~~~Imoveis Disponives~~~~~~";
                        printVetorImoveis(imobiliariaChico.getImoveisPorBairro(str));
                        menuRMV();
                        std::cin >> opcao;
                        getchar();
                        switch (opcao)
                        {
                            case 1://remover
                                limpaTela();
                                printVetorImoveis(imobiliariaChico.getImoveisPorBairro(str));
                                std::cout << "\nDigite o indice do imovel que deseja remover: ";
                                std::cin >> it;
                                getchar();
                                imobiliariaChico.removerImovel(it);
                                std::cout << "\nRemocao finalizada, aperte ENTER.";
                                getchar();
                                break;
                            case 2://modificar
                                limpaTela();
                                printVetorImoveis(imobiliariaChico.getImoveisPorBairro(str));
                                std::cout << "\nDigite o indice do imovel que deseja recadastrar: ";
                                std::cin >> it;
                                getchar();
                                if(vetorChico[it-1]->getTipoOferta() == 1){
                                    imobiliariaChico.editarApartamento(it, cadastraApartamento());
                                }else if(vetorChico[it-1]->getTipoOferta() == 2){
                                    imobiliariaChico.editarCasa(it, cadastraCasa());
                                }else if(vetorChico[it-1]->getTipoOferta() == 3){
                                    imobiliariaChico.editarTerreno(it, cadastraTerreno());
                                }
                                std::cout << "\nEdicao finalizada, aperte ENTER.";
                                getchar();
                                break;
                            case 3://vazar
                                limpaTela();
                                break;
                            default:
                                limpaTela();
                                std::cout << "Opcao invalida, aperte ENTER.";
                                getchar();
                                break;
                        }
                        break;
                    case 5://busca valor
                        limpaTela();
                        std::cout << "Digite um valor em R$: ";
                        std::cin >> db;
                        getchar();
                        buscaValor();
                        std::cin >> opcao;
                        getchar();
                        switch (opcao)
                        {
                            case 1:
                                limpaTela();
                                std::cout << "~~~~~~Imoveis Disponives~~~~~~";
                                printVetorImoveis(imobiliariaChico.getImoveisPorValor(db, true));
                                menuRMV();
                                std::cin >> opcao;
                                getchar();
                                switch (opcao)
                                {
                                    case 1://remover
                                        limpaTela();
                                        printVetorImoveis(imobiliariaChico.getImoveisPorValor(db, true));
                                        std::cout << "\nDigite o indice do imovel que deseja remover: ";
                                        std::cin >> it;
                                        getchar();
                                        imobiliariaChico.removerImovel(it);
                                        std::cout << "\nRemocao finalizada, aperte ENTER.";
                                        getchar();
                                        break;
                                    case 2://modificar
                                        limpaTela();
                                        printVetorImoveis(imobiliariaChico.getImoveisPorValor(db, true));
                                        std::cout << "\nDigite o indice do imovel que deseja recadastrar: ";
                                        std::cin >> it;
                                        getchar();
                                        if(vetorChico[it-1]->getTipoOferta() == 1){
                                            imobiliariaChico.editarApartamento(it, cadastraApartamento());
                                        }else if(vetorChico[it-1]->getTipoOferta() == 2){
                                            imobiliariaChico.editarCasa(it, cadastraCasa());
                                        }else if(vetorChico[it-1]->getTipoOferta() == 3){
                                            imobiliariaChico.editarTerreno(it, cadastraTerreno());
                                        }
                                        std::cout << "\nEdicao finalizada, aperte ENTER.";
                                        getchar();
                                        break;
                                    case 3://vazar
                                        limpaTela();
                                        break;
                                    default:
                                        limpaTela();
                                        std::cout << "Opcao invalida, aperte ENTER.";
                                        getchar();
                                        break;
                                }                               
                                break;
                            case 2:
                                limpaTela();
                                std::cout << "~~~~~~Imoveis Disponives~~~~~~";
                                printVetorImoveis(imobiliariaChico.getImoveisPorValor(db, false));
                                menuRMV();
                                std::cin >> opcao;
                                getchar();
                                switch (opcao)
                                {
                                    case 1://remover
                                        limpaTela();
                                        printVetorImoveis(imobiliariaChico.getImoveisPorValor(db, false));
                                        std::cout << "\nDigite o indice do imovel que deseja remover: ";
                                        std::cin >> it;
                                        getchar();
                                        imobiliariaChico.removerImovel(it);
                                        std::cout << "\nRemocao finalizada, aperte ENTER.";
                                        getchar();
                                        break;
                                    case 2://modificar
                                        limpaTela();
                                        printVetorImoveis(imobiliariaChico.getImoveisPorValor(db, false));
                                        std::cout << "\nDigite o indice do imovel que deseja recadastrar: ";
                                        std::cin >> it;
                                        getchar();
                                        if(vetorChico[it-1]->getTipoOferta() == 1){
                                            imobiliariaChico.editarApartamento(it, cadastraApartamento());
                                        }else if(vetorChico[it-1]->getTipoOferta() == 2){
                                            imobiliariaChico.editarCasa(it, cadastraCasa());
                                        }else if(vetorChico[it-1]->getTipoOferta() == 3){
                                            imobiliariaChico.editarTerreno(it, cadastraTerreno());
                                        }
                                        std::cout << "\nEdicao finalizada, aperte ENTER.";
                                        getchar();
                                        break;
                                    case 3://vazar
                                        limpaTela();
                                        break;
                                    default:
                                        limpaTela();
                                        std::cout << "Opcao invalida, aperte ENTER.";
                                        getchar();
                                        break;
                                }
                                break;
                            default:
                                limpaTela();
                                std::cout << "Opcao invalida, aperte ENTER.";
                                getchar();
                                break;
                        }
                        break;
                    default:
                        limpaTela();
                        std::cout << "Opcao invalida, aperte ENTER.";
                        getchar();
                        break;
                }
                break;

            case 4://Salvar e sair
                limpaTela();
                salvarArquivo(imobiliariaChico.getImoveis());
                loop = false;
                break;
            default:
                limpaTela();
                std::cout << "Opcao invalida, aperte ENTER.";
                getchar();
                break;
        }
        std::cout << "Programa finalizado." << std::endl;
    }
    return 0;
}