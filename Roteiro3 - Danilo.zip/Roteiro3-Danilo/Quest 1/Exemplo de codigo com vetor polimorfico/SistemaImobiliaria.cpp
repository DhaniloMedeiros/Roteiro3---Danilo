#include "SistemaImobiliaria.h"
#include <string>
#include <algorithm>

SistemaImobiliaria::SistemaImobiliaria(){
}//porra nenhuma;

void SistemaImobiliaria::cadastraApartamento(Apartamento* imv){
    imv->setIndice(imoveis.size()+1);
    imoveis.push_back(imv);
}

void SistemaImobiliaria::cadastraCasa(Casa* imv){
    imv->setIndice(imoveis.size()+1);
    imoveis.push_back(imv);
}

void SistemaImobiliaria::cadastraTerreno(Terreno* imv){
    imv->setIndice(imoveis.size()+1);
    imoveis.push_back(imv);
}

void SistemaImobiliaria::setImoveis(std::vector<Imovel*> imv){
    imoveis = imv;
}

std::vector<Imovel*> SistemaImobiliaria::getImoveis(){
    return imoveis;
}

std::vector<std::string> SistemaImobiliaria::getDescricaoImoveis(){
    std::vector<std::string> descricoes;
    size_t tam = imoveis.size();//pega o tamanho do vector e faz um for ate estourar
    if(tam != 0){
        int i;
        for(i = 0; i < tam; i++){
            descricoes.push_back(imoveis[i]->getDescricao());
        }
        return descricoes;
    }
}

std::vector<Imovel*> SistemaImobiliaria::getImoveisPorTipo(int tipo){
    size_t tam = imoveis.size();
    std::vector<Imovel*> vetorRetornado;
    if(tam != 0){
        int i;
        for(i = 0; i < tam; i++){
            if(imoveis[i]->getTipoOferta() == tipo)
                vetorRetornado.push_back(imoveis[i]);
        }
        return vetorRetornado;
    }
}

std::vector<Imovel*> SistemaImobiliaria::getImoveisPorCidade(std::string str){
    size_t tam = imoveis.size();
    std::transform(str.begin(), str.end(),str.begin(), ::toupper);
    std::vector<Imovel*> vetorRetornado;
    if(tam != 0){
        int i;
        for(i = 0; i < tam; i++){
            Endereco end = imoveis[i]->getEndereco();
            std::string cidade = end.getCidade();
            size_t found = cidade.find(str);

            if(found != std::string::npos)
                vetorRetornado.push_back(imoveis[i]);
        }
        return vetorRetornado;
    }
}

std::vector<Imovel*> SistemaImobiliaria::getImoveisPorDescricao(std::string str){
    size_t tam = imoveis.size();
    std::transform(str.begin(), str.end(),str.begin(), ::toupper);
    std::vector<Imovel*> vetorRetornado;
    if(tam != 0){
        int i;
        for(i = 0; i < tam; i++){
            std::string descricao = imoveis[i]->getDescricao();
            size_t found = descricao.find(str);

            if(found != std::string::npos)
                vetorRetornado.push_back(imoveis[i]);
        }
        return vetorRetornado;
    }
}

std::vector<Imovel*> SistemaImobiliaria::getImoveisPorBairro(std::string str){
    size_t tam = imoveis.size();
    std::transform(str.begin(), str.end(),str.begin(), ::toupper);
    std::vector<Imovel*> vetorRetornado;
    if(tam != 0){
        int i;
        for(i = 0; i < tam; i++){
            Endereco end = imoveis[i]->getEndereco();
            std::string bairro = end.getBairro();
            size_t found = bairro.find(str);

            if(found != std::string::npos)
                vetorRetornado.push_back(imoveis[i]);
        }
        return vetorRetornado;
    }
}

std::vector<Imovel*> SistemaImobiliaria::getImoveisPorValor(double precoAlvo, bool maior_menor){//true maior, false menor
    size_t tam = imoveis.size();
    std::vector<Imovel*> vetorRetornado;
    if(tam != 0){
        int i;
        for(i = 0; i < tam; i++){
            if(maior_menor){
                if(imoveis[i]->getValor() >= precoAlvo)//true maior
                    vetorRetornado.push_back(imoveis[i]);
            }else{
                if(imoveis[i]->getValor() <= precoAlvo)//false menor
                    vetorRetornado.push_back(imoveis[i]);
            }
        }
        return vetorRetornado;
    }
}

void SistemaImobiliaria::removerImovel(int index){
    size_t tam = imoveis.size();
    int i;
    int aux;
    for(i = index; i < tam; i++){
        aux = imoveis[i]->getIndice();
        imoveis[i]->setIndice(aux - 1);

    }
    imoveis.erase(imoveis.begin() + (index-1));
}

void SistemaImobiliaria::editarApartamento(int index, Apartamento* im){
    int aux = imoveis[index - 1]->getIndice();
    imoveis[index-1] = im;
    imoveis[index-1]->setIndice(aux);
}

void SistemaImobiliaria::editarCasa(int index, Casa* im){
    int aux = imoveis[index - 1]->getIndice();
    imoveis[index-1] = im;
    imoveis[index-1]->setIndice(aux);
}

void SistemaImobiliaria::editarTerreno(int index, Terreno* im){
    int aux = imoveis[index - 1]->getIndice();
    imoveis[index-1] = im;
    imoveis[index-1]->setIndice(aux);
}

